def print_bill():
     products = {'TSHIRT':{'category':'Clothing','price':1000,'discount':10}, 'JACKET':{'category':'Clothing','price':2000,'discount':5}, 'CAP':{'category':'Clothing','price':500,'discount':20}, 
'NOTEBOOK':{'category':'Stationery','price':200,'discount':20}, 'PENS':{'category':'Stationery','price':300,'discount':10}, 'MARKERS':{'category':'Stationery','price':500,'discount':5}}
     input = open("input_file.txt","r");
     lines = input.readlines()
     count = total_amount = total_discount_amount = 0  
     for line in lines:
        count += 1
        items = line.split(' ')
        if(items[0] == 'ADD_ITEM'):
            category = products[items[1]]['category']
            price = products[items[1]]['price']
            discount = products[items[1]]['discount']
            if(category == 'Clothing' and int(items[2]) > 2 or category == 'Stationery' and int(items[2]) > 3):
                print('ERROR_QUANTITY_EXCEEDED')
                continue 
            total_amount = (total_amount + price) * int(items[2])
            if(total_amount > 1000):
                if(total_amount > 3000): discount_amount = ((price * int(items[2])) * (discount + 5)) / 100
                else: discount_amount = ((price * int(items[2])) * discount) / 100
                total_discount_amount = total_discount_amount + discount_amount
            else: total_discount_amount = 0
            print('ITEM_ADDED')
     total_amount_to_pay = total_amount - total_discount_amount
     print('TOTAL_DISCOUNT '+ '{0:.2f}'.format(total_discount_amount))
     print('TOTAL_AMOUNT_TO_PAY '+ '{0:.2f}'.format(total_amount_to_pay + ((total_amount_to_pay * 10) / 100)))
     
